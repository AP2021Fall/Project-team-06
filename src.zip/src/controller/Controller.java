package controller;

public class Controller {
	private static Controller controller = new Controller();
	
	public static Controller getController() {
		return controller;
	}
}
